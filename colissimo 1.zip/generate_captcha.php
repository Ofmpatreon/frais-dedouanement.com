<?php
session_start();

function generateCaptcha() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $captchaString = '';
    for ($i = 0; $i < 6; $i++) {
        $captchaString .= $characters[rand(0, strlen($characters) - 1)];
    }
    $_SESSION['captcha'] = $captchaString;

    $image = imagecreatetruecolor(150, 50);
    $backgroundColor = imagecolorallocate($image, 255, 255, 255); // Blanc
    $textColor = imagecolorallocate($image, 0, 0, 0); // Noir
    imagefilledrectangle($image, 0, 0, 150, 50, $backgroundColor);
    imagestring($image, 5, 20, 15, $captchaString, $textColor);

    for ($i = 0; $i < 50; $i++) {
        imagesetpixel($image, rand(0, 150), rand(0, 50), $textColor);
    }

    // Afficher l'image du captcha
    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
}

generateCaptcha();
